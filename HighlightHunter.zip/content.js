// Initializes variables for managing word highlighting
let highlighterEnabled = true; // Flag to toggle the highlighter on/off
let lastClickedWord = ''; // Stores the last clicked word
let wordColors = {}; // Maps words to their assigned highlight colors

console.log("Content script loaded");

// Listens for messages from the background script to toggle highlighter
browser.runtime.onMessage.addListener((message) => {
  console.log("Received message from background:", message);

  if (message.type === "TOGGLE_HIGHLIGHTER") {
    highlighterEnabled = message.enabled; // Enables/disables the highlighter based on the message
  }
});

// Event listener for double-clicking a word to highlight it
document.addEventListener('dblclick', () => {
  if (!highlighterEnabled) return;

  const selection = window.getSelection().toString().trim(); // Get the selected text
  console.log("Double-click detected, selection:", selection);

  if (selection.length > 0) {
    lastClickedWord = selection; // Store the selected word
    const lower = selection.toLowerCase();

    if (!wordColors[lower]) {
      wordColors[lower] = getAccessibleBackgroundColor(); // Assign a new color if it's a new word
    }

    const color = wordColors[lower];
    const regex = new RegExp(`(${escapeRegExp(selection)})`, 'gi'); // Regex to match the selected word
    highlightText(regex, color); // Highlight the word with the selected color
  }
});

// Event listener for triple-clicking to change the color of the last clicked word
document.addEventListener('click', (e) => {
  if (!highlighterEnabled) return;

  if (e.detail === 3 && lastClickedWord) {
    const newColor = getAccessibleBackgroundColor(); // Get a new color for the word
    wordColors[lastClickedWord.toLowerCase()] = newColor; // Update the word's color
    const regex = new RegExp(`(${escapeRegExp(lastClickedWord)})`, 'gi');
    clearHighlightsForWord(lastClickedWord); // Remove existing highlights
    highlightText(regex, newColor); // Apply the new color to the word
  }
});

// Event listener for right-click to clear all highlights
document.addEventListener('contextmenu', () => {
  if (!highlighterEnabled) return;

  clearAllHighlights(); // Clear all highlights
  wordColors = {}; // Reset the word color map
});

// Function to highlight text matching the regex with a specified background color
function highlightText(regex, backgroundColor) {
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
  const nodes = [];

  while (walker.nextNode()) {
    const node = walker.currentNode;
    if (regex.test(node.nodeValue) && node.parentNode.nodeName !== 'MARK') {
      nodes.push(node); // Collect nodes that match the regex
    }
  }

  nodes.forEach(node => {
    const span = document.createElement('span');
    const textColor = getComputedStyle(node.parentNode).color || "#000000";
    const fontColor = getContrastingTextColor(backgroundColor, textColor); // Get contrasting font color
    span.innerHTML = node.nodeValue.replace(regex, `<mark style="background-color: ${backgroundColor}; color: ${fontColor}">$1</mark>`);
    const temp = document.createElement('div');
    temp.appendChild(span);
    node.parentNode.replaceChild(temp.firstChild, node); // Replace original text with highlighted span
  });
}

// Function to clear all highlights
function clearAllHighlights() {
  const marks = document.querySelectorAll('mark');
  marks.forEach(mark => {
    const parent = mark.parentNode;
    parent.replaceChild(document.createTextNode(mark.textContent), mark);
    parent.normalize(); // Normalize the DOM structure
  });
}

// Function to clear highlights for a specific word
function clearHighlightsForWord(word) {
  const marks = document.querySelectorAll('mark');
  marks.forEach(mark => {
    if (mark.textContent.toLowerCase() === word.toLowerCase()) {
      const parent = mark.parentNode;
      parent.replaceChild(document.createTextNode(mark.textContent), mark);
      parent.normalize(); // Normalize the DOM structure
    }
  });
}

// Function to get a random background color
function getAccessibleBackgroundColor() {
  return getRandomColor(); // Generate a random color for the background
}

// Function to generate a random hex color
function getRandomColor() {
  const letters = '0123456789ABCDEF';
  let color = '#';
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}

// Function to escape special characters in a string for use in a regular expression
function escapeRegExp(string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// Function to get a contrasting text color based on the background color
function getContrastingTextColor(bgColor, fallbackColor = '#000') {
  const r = parseInt(bgColor.substr(1, 2), 16);
  const g = parseInt(bgColor.substr(3, 2), 16);
  const b = parseInt(bgColor.substr(5, 2), 16);

  const brightness = (r * 299 + g * 587 + b * 114) / 1000;
  return brightness > 125 ? '#000000' : '#FFFFFF'; // Return black or white text color based on brightness
}
