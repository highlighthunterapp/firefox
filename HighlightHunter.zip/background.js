// Initialize an object to track the enabled/disabled state of the highlighter for each tab
let enabledTabs = {};

// Event listener for when the browser action (icon) is clicked
browser.browserAction.onClicked.addListener(async (tab) => {
  const tabId = tab.id; // Get the current tab's ID

  enabledTabs[tabId] = !enabledTabs[tabId]; // Toggle the highlighter's state for the current tab
  const isEnabled = enabledTabs[tabId]; // Get the new state (enabled or disabled)

  console.log("Icon clicked. Highlighter enabled:", isEnabled);

  // Send a message to the content script of the current tab to toggle the highlighter
  browser.tabs.sendMessage(tabId, {
    type: "TOGGLE_HIGHLIGHTER",
    enabled: isEnabled
  });

  // Change the browser action (icon) based on whether the highlighter is enabled or not
  browser.browserAction.setIcon({
    tabId: tabId,
    path: isEnabled ? "icon.png" : "iconoff.png" // Set the appropriate icon (on or off)
  });
});
